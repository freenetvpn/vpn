<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
		<meta name="description" content=""/>
		<meta name="keywords" content=""/>
		<meta name="author" content=""/>
		         <?php foreach ($this->user_model->view_asset() as $row): ?>
<title><?= $row['web']?></title>
			 <?php endforeach; ?> 
		
		
		<link href="<?php echo  base_url('asset/css/bootstrap.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/css/bootstrap.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/dist/css/AdminLTE.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/dist/css/skins/_all-skins.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/css/bootstrap-dialog.min.css')?>" rel="stylesheet"/>
		<link href="<?php echo  base_url('asset/css/material-kit.css')?>" rel="stylesheet"/>
		
		<?php foreach ($this->user_model->view_user($_SESSION['username']) as $row): ?>
		<link rel="icon" href="<?= $row['png']?>" type="image/x-icon"> 
        <link rel="shortcut icon" href="<?= $row['png']?>" type="image/x-icon"> 
        <?php endforeach; ?> 
            
		<link href="<?= base_url('asset/css/sb-admin-2.css')?>" rel="stylesheet"/>
		<link href="<?= base_url('asset/css/bootstrap-datepicker3.min.css')?>" rel="stylesheet"/>
		<link href="<?= base_url('asset/css/bootstrap-dialog.min.css')?>" rel="stylesheet"/>
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
		<!--[if lt IE 9]>
		<script src="<?= base_url('asset/js/html5shiv.js');?>"></script>
		<script src="<?= base_url('asset/js/respond.min.js');?>"></script>
		<![endif]-->
		<link rel="shortcut icon" href="<?= base_url('images/ico/favicon.ico')?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?= base_url('images/ico/apple-touch-icon-144-precomposed.png')?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?= base_url('images/ico/apple-touch-icon-114-precomposed.png')?>"/>
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?= base_url('images/ico/apple-touch-icon-72-precomposed.png')?>"/>
		<link rel="apple-touch-icon-precomposed" href="<?= base_url('images/ico/apple-touch-icon-57-precomposed.png')?>"/>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
		
		<!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="<?php echo  base_url('asset/font-awesome/css/font-awesome.min.css')?>" rel="stylesheet"/>
    <!-- Plugin CSS -->
    <link href="<?php echo  base_url('asset/css/animate.min.css" type="text/css')?>" rel="stylesheet"/>
    <!-- Custom CSS -->
    <link href="<?php echo  base_url('asset/css/creative.css" type="text/css')?>" rel="stylesheet"/>
  	
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
		<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
		
		
</head>
		
		
		
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"> 
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&amp;subset=thai,latin" rel="stylesheet" type="text/css"> 
  <style>
		body {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
		h1 {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
    </style> 
	</head>
	<body>
                    
<div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0; bg-color:red">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                
            </button>
         <a class="navbar-brand page-scroll" href="/seller">
         
<img src="<?php foreach ($this->user_model->view_user($_SESSION['username']) as $row): ?><?= $row['png']?><?php endforeach; ?>" width="25px" style="display:inline; margin:0 2px 3px 0"> <font color="#000000"> <?php foreach ($this->user_model->view_asset() as $row): ?><?= $row['web']?><?php endforeach; ?></a></font> 
			 
</div>
        
        

        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search">
                        <div class="row">
                            <div class="col-xs-5">
                                <span class="fa-stack fa-3x">
                                    <?php foreach ($this->user_model->view_user($_SESSION['username']) as $row): ?>
                                       
                                 <a href="/seller/profile" target="_top"><img src="<?= $row['png']?>" width="90" height="90" alt="logo.ico" /></a>
                                    <?php endforeach; ?>
                                        
                                </span>
                            </div>
                            <?php if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true): ?>
                            <div class="col-xs-7">
                             <?php foreach ($this->user_model->view_user($_SESSION['username']) as $row): ?>
                                <h4 class="text-muted"><?php if ($_SESSION['is_admin']) { echo '<h3><b>'.$_SESSION['username'].'</b></3><h4><b>ผู้ดูแลระบบ</b></h4>'; } else { echo '<h3><b>'.$_SESSION['username'].'</b></3><h4><b>สมาชิกที่ '.$row['id'].'</b></h4>'; } ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </li>
                    
        
						<?php if ($_SESSION['is_admin']): ?>
							
        </li>
        <li>
                                <a href="<?= base_url('panel/admin/'.$_SESSION['username'].'') ?>"><i class="fa fa-th-list fa-fw"></i> เซิฟร์เวอร์</a>
                            </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-address-book-o"> <b>จัดการข้อมูลสมาชิก </b></i> 

            <span class="pull-right-container">
              <i class="fa fa-chevron-circle-down pull-right"></i>
            </span>
          </a>          
          <ul class="treeview-menu">
            <div><a class="form-control"  style="width:85%; border:100% #000000" href="/admin/view_users"> <i class="fa fa-retweet"></i><b> ค้นหาชื่อสมาชิก</b></a></div>
            <div><a class="form-control"  style="width:85%; border:100% #000000" href="/admin/view_account"><i class="fa fa-paper-plane-o"> </i> <b> บัญชีวีพีเอ็น</b></a></div>
							
            
          </ul>
          </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-sliders"> <b> ตั้งค่า </b></i> 

            <span class="pull-right-container">
              <i class="fa fa-chevron-circle-down pull-right"></i>
            </span>
          </a>          
          <ul class="treeview-menu">
                           <div><a class="form-control"  style="width:85%; border:100% #000000" href="/admin/msg"> <i class="fa fa-edit"></i><b> อัปเดตข่าวสาร</b></a></div>
                            <div><a class="form-control"  style="width:85%; border:100% #000000" href="/admin/setting_wallet"><i class="fa fa-hourglass-start"> </i><b> ทรูวอเล็ท</b></a></div>
							<div><a class="form-control"  style="width:85%; border:100% #000000" href="/admin/setting_web"><i class="fa fa-globe"> </i><b> แก้เว็บไซ์ต</b></a></div>
							<div><a class="form-control"  style="width:85%; border:100% #000000" href="/admin/setting_token"><i class="fa fa-bullhorn"> </i><b> แจ้งเตือนไลน์</b></a></div>
							<div><a class="form-control"  style="width:85%; border:100% #000000" href="/admin/download"><i class="fa fa-edit"> </i><b> เพิ่มไฟล์ Ovpn</b></a></div>
							
         </ul>
        
                            
                            
                            
							
                        <?php endif; ?>
                            
                           <li>
                                       
                            
                              <a href="<?= base_url('/seller/profile') ?>"><i class="fa fa-envira"></i> ข้อมูลโปรไฟล์</a>
                        </li>

                            <li>
                                       
                            
                              <a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/server') ?>"><i class="fa fa-shopping-cart fa-fw"></i> เลือกแพ็กเกจ</a>
                        </li>
                        <li>
                              <a href="<?= base_url('panel/reseller/cek_account/') ?>"><i class="fa fa-users"></i> ตรวจสอบบันชี / ดาวน์โหลดไฟล์</a>
                        </li> 
                       
                        
                        
                        
                        
                           

                        <li>
							<a href="<?= base_url('panel/'.$_SESSION['username'].'/setting')?>"><i class="fa fa-gear fa-fw"></i> เปลียนรหัสผ่าน</a>
                        </li>
                        
					  <li>
                        <a href="<?= base_url('panel/'.$_SESSION['username'].'/logout')?>"><i class="fa fa-sign-out fa-fw"></i> ออกจากระบบ</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</div>
​