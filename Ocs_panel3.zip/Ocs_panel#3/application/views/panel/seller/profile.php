﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
                    
      <h3>
       ตั้งค่าโปรไฟล์
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">ตั้งค่าโปรไฟล์</li>
    </ol>
   </div>
    </div>
    <div class="well"> 
    <div class="row">
        <center>
           
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   
				
				<?php foreach ($this->user_model->view_user($_SESSION['username']) as $row): ?>
					<div class="form-group">
     
            
    <div class="beta site-title"><img src="<?= $row['png']?>" width="100" height="100" alt="logo.ico" /> <a href="/seller/edit_image" target="_top"> <i class="fa fa-edit"></i></a>		</div>
   
				
				<b>
					<br>
						<h4 for="png">ไอดี : <?= $row['id']?></h4> 
						
						
					<br>
						<h4 for="png">ชื่อผู้ใช้ : <?= $row['username']?><!--<a href="/seller/edit_user" target="_top"> <i class="fa fa-edit"></i></a>--></h4> 
					<br>
						<h4 for="email">อีเมล : <?= $row['email']?><a href="/seller/edit_email" target="_top"> <i class="fa fa-edit"></i></a></h4> 
					
						
						
			<?php endforeach; ?>
					
		   
		  