<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
date_default_timezone_set('Asia/Bangkok');  ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            
            
                
      <h3>
       สร้างบัญชี OPENVPN-SSH
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">สร้างบัญชี</li>
    </ol>
    
        
        </div>
    </div><center>
    
           
            <!--<div class="btn btn-primary" class="well"> มี <?= $user -> saldo ?> เครดิต </div>-->
           
        
     </center>
    <h4></h4>

            <div class="col-lg-5">
                <?php if (isset($message)) {echo $message; }?>
                  </div>
               
                    <div class="panel-body">
					<?php if (validation_errors()) : ?>
					<div class="col-md-10">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-10">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
					<?php endif;?>
					<?= form_open() ?>
         
               
                <!--<div class="panel panel-success">-->
				<!--class="category text-gray-->
                    <div class="panel-heading">
                        <b><center><span style="font-size: 20px;" class="label label-success">สร้างบัญชีสำหรับ [ <?= $server->ServerName ?> ]</span></center></b>
                    </div>
               
						<div align="center">
						<div class="form-group">
							<label for="username"><font color="000000">ชื่อผู้ใช้</font></label>
							<input type="text" name="username" class="form-control text-center" style="width:30%; border:5px" id="username" placeholder="อย่างน้อย 1ตัว ห้ามใช้ภาษาไทย" autofocus required/>
						</div>
						
                        <div class="form-group">
                            <label for="password"><font color="000000">รหัสผ่าน</font></label>
                            <input class="form-control text-center" style="width:30%; border:5px" type="text" name="password" id="password" placeholder="อย่างน้อย 1ตัว ห้ามใช้ภาษาไทย">
                        </div>
						<!--<div class="form-group">
                            <label>จำนวนวันใช้งาน</label>
						  <input id="f3" class="form-control" style="width:20%; border:5px" onkeyup="multiply('2.3333333333333', 'f3', 'b', '*')" type="number" name="buy_day" placeholder="จำนวนวันใช้งาน 1 7 15 31 62 93" required="">
                        </div>-->
                    
                    <label for=""></label>
                    <div class="text-center">
                    <input type="submit" class="btn btn-success" style="width:20%; border:5px" value="สร้างบันชี"/>
                    </form>
                </div>
                </div>
            <!--</div>-->
    </div>
</div>
     