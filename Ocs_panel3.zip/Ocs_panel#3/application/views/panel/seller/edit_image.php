<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
                   
      <h3>
       ตั้งค่าโปรไฟล์
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
        <li><a href="/seller/profile"> โปรไฟล์ </a></li>
		<li class="active">แก้ไขรูปโปรไฟล์</li>
    </ol>
   </div>
    </div>
    <div class="well"> 
    <div class="row">
        <center>
           
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   <?= form_open() ?>
				
				<?php foreach ($this->user_model->view_user($_SESSION['username']) as $row): ?>
					<div class="form-group">
     
            
    <div class="beta site-title"><a href="/seller/edit_image" target="_top"><img src="<?= $row['png']?>" width="100" height="100" alt="logo.ico" /></a>		</div>
   
				
				<br>
					
						<label for="png">ใส่ลิ้งรูปโปรไฟล์</label>
						<input type="text" name="png" class="text-center form-control" id="png" value="<?= $row['png']?>" placeholder="www.smile-vpn.net/image.png" />
						</div>
						
						<input type="submit" class="btn btn-primary form-control" value="อัปเดตโปรไฟล์"/>
					
			   </form></div></div>
			<?php endforeach; ?>
					
		   
		  