<?php defined('BASEPATH') OR exit('No direct script access allowed');  ?>
<?php foreach ($this->user_model->view_token() as $row): ?>
<?php
$host=getenv('HTTP_HOST');
$line_api = 'https://notify-api.line.me/api/notify';
$access_token = $row['wallet'];
endforeach;
$str ='';
if (isset($yes)) {
$str ='
******************
 🌍 http://'.$host.'
 🤵 '.$_SESSION['username'].'
 ⏳ เติมเงิน '.$money.' บาท
 ♻️ ยอดร่วม '.$saldo.' บาท
 ✡️ '.$idwallet;
 } else if (isset($no)) {
    $str ='
******************
 🌍 http://'.$host.'
 🤵 '.$_SESSION['username'].'
 📵 '.$filed.'
 ♻️ '.$idwallet;
 } 
?>


	
<div id="page-wrapper" style="min-height: 406px;"> 
   <div class="row"> 
    <div class="col-lg-12"> 
     <h3> <a href="/panel/reseller/smile/admin-smile"> <font color="000000">เติมเงินเข้าระบบ </font></a> </h3> 
     <ol class="breadcrumb"> 
      <li><a href="/"><i class="fa fa-th-list fa-fw"></i> หน้าหลัก</a></li> 
      <li class="active">AutoWallet</li> 
     </ol> 
     
     
     <ol class="breadcrumb"> <br>
     <div align="center"> 
       <center> 
        
        
         <strong><p> โอน TrueWallet มาที่เบอร์ <br>
         
     <font color="red"><?= $phone ?></font> </p>
     <?php if ($ewallet > 14000) { ?>
     <strong><p> หรือโอนผ่านแอปธนาคารเข้า E-Wallet<br>
         
     <font color="red"><?= $ewallet ?></font> </p>
<?php } ?>
 <p> แล้วก็นำเลขที่อ้างอิงมายืนยันเพื่อเติมเครดิต <br>
หรือวันที่และเวลาโอนตามสลิป <br>
ตัวอย่าง 31/12/19 23:59</p>

<p><font color="#FF7300"> ไม่มีขั้นต่ำ โอนได้ไม่จำกัดจำนวน </font></p>
          
          <center> 
              <?php if (isset($nologin)) {echo $nologin;} ?>
           <?php if (isset($no)) {echo $no;} ?>
<?php if (isset($noo)) {echo $noo;} ?>
			   <?php if (isset($yes)) {echo $yes;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   <?= form_open() ?>
					<div class="form-group">
               
	        
             <input type="text" style="width:210px; border:1px" class="form-control text-center" maxlength="14" name="wallet"  placeholder="เลขอ้างอิงหรือวันเวลาโอน" autofocus>
                 
           
            <input class="btn btn-warning btn-round" class="form-control" type="submit" value="ยืนยันเลขอ้างอิง" name="wallet" onclick="this.disabled=1;this.value='รอสักครู่กำลังตรวจสอบเลขอ้างอิง...';document.forms[0].submit();loading()" style="height:40px;font-size16px"> 
           </dev> 
     <br>     <br>
           <p>&gt;&gt;&gt; เครดิตจะเพิ่มโดยอัตโนมัต &lt;&lt;&lt;</p> 
           <?php foreach ($this->user_model->view_asset() as $row): ?>
           <p><a href="<?= $row['link']; ?>">แจ้งปัญหาคลิกที่นี่...</a></p> 
           <?php endforeach; ?>
           <center>
            <p></p>
           </center> 
          </center> </strong>
       
       </center>
       <strong> </strong>
      </div>
      <strong> <p></p> <p></p> </strong>
     </div>
     </div> 
</div> 
</div> 
 </body>
</html>
<?php

$image_thumbnail_url = '';  // ขนาดสูงสุด 240?240px JPEG
$image_fullsize_url = '';  // ขนาดสูงสุด 1024?1024px JPEG
$sticker_package_id = '';  // Package ID ของสติกเกอร์
$sticker_id = '';    // ID ของสติกเกอร์

$message_data = array(
 'message' => $str,
 'imageThumbnail' => $image_thumbnail_url,
 'imageFullsize' => $image_fullsize_url,
 'stickerPackageId' => $sticker_package_id,
 'stickerId' => $sticker_id
);
if (isset($yes)) {
$result = send_notify_message($line_api, $access_token, $message_data);
print_r($result);
} else if (isset($no)) { 
$result = send_notify_message($line_api, $access_token, $message_data);
print_r($result);
} else if  (isset($nologin)) {
$result = send_notify_message($line_api, $access_token, $message_data);
print_r($result);
}
function send_notify_message($line_api, $access_token, $message_data)
{
 $headers = array('Method: POST', 'Content-type: multipart/form-data', 'Authorization: Bearer '.$access_token );

 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $line_api);
 curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $message_data);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $result = curl_exec($ch);
 // Check Error
 if(curl_error($ch))
 {
  $return_array = array( 'status' => '000: send fail', 'message' => curl_error($ch) ); 
 }
 else
 {
  $return_array = json_decode($result, true);
 }
 curl_close($ch);
 
}


?>