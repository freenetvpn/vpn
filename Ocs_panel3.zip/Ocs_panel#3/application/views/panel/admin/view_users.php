<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	

<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
            <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">ค้นหารายชื่อสมาชิก</li>
    </ol>
             <center>   
        <?php if ( isset($message)){ echo $message; } ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			      </center>   
			  <form action="/admin/view_users" method="post" accept-charset="utf-8">
				
				
					<div class="form-group">
     
            
    
					
						
						<input type="text" name="username" class="text-center form-control bg-black" id="username"  value="<?php if ( isset($user -> username)){ echo $user -> username; } else {  if (isset($sshuser)) { echo $sshuser;} }?>" placeholder="<?php if ( isset($user -> username)){ echo $user -> username; } else {  if (isset($sshuser)) { echo $sshuser;} else { echo 'ป้อนชื่อผู้ใช้ที่ต้องการแก้ไข';} }?>" />
						</div>
						
						<input type="submit" class="btn btn-primary form-control" value="ค้นหาบัญชีลูกค้า"/>
					
			   </form>
			
			
    <h3></h3>
    

               <?php
			   if ( isset($user -> username)){ $sshuser=$user -> username; }
			   if ( isset($sshuser)){ ?>
             
                 <?php foreach ($this->user_model->view_user($sshuser) as $row): 
          $username=$row['username'];
         if ($username == '') {
			 
		 } else {		 ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <i class="fa fa-group fa-fw"></i> ข้อมูลของบัญชี <?= $row['username'] ?>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">

                        <table class="table table-hover">
                            <thead><center>
                                <tr> 
                                    <th><center>โปรไฟล์</center></th>
                                    <th><center>ชื่อผู้ใช้</center></th>
                                  <th><center>เครดิต</center></th>
                                    <th><center>สถานะ</center></th>
                                    <th><center>วันที่เป็นสมาชิก</center></th>
                                     <th><center>อัปเดตเครดิต</center></th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                             
            
                                
		                     <tr>
                                                <td><center>
<img class='img-circle' src="<?= $row['png']?>" width="20" height="20" alt="logo.ico" />
</center></td>
                                                <td><center><?= $row['username'] ?></center></td>
                                                <td><center><?= $row['saldo'] ?></center></td>
                                                <td><center><?php if ($row['is_admin'] == '1' ) { echo '<font color="green">admin</font>';} else { echo '<font color="red">seller</font>'; } ?></center></td>
                                                <td><center><?= $row['created_at']?></center></td>
                                                
                                                
                                                
                                                 
                                                
                                                <td><center>
                                                    <button data-toggle="modal" data-target="#<?= $row['username'] ?>" class="animated infinite pulse col-md-20 badge bg-green" type="button" ><i class="fa fa-joomla"></i></button>
   <div class="bg-info modal fade" id="<?= $row['username'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <label for="expired"><font size=3 color="000000">อัปเดตเครดิต <?= $row['username'] ?></font></label>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <center>
<form action="/admin/edit_saldo/<?= $row['id'] ?>" method="post" accept-charset="utf-8">
	
	<div class="form-group">
                            
                             <div class="form-group">
                            <label for="password"><font color="000000">จำนวนเครดิต</font></label>
                            <input class="form-control text-center" style="width:80%; border:5px" type="number" name="saldo" id="password" placeholder="อย่างน้อย 1ตัว เฉพาะตัวเลข">
                        </div>
                        
                      <font color="000000">
                            <input type="checkbox" name="chek" value="1"/> เพิ่มเครดิต
						<input type="checkbox" name="chek" value="0"/> แก้ไขเครดิต
                        </font>
    
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">ยกเลิก</button>
        <button type="submit" class="btn btn-success">ยืนยัน</button>
       </div> </form></center>   
      </div>
    </div>
  </div>
</div>
 </div></center></td>
                                                
                                             </tr>
                                       
                                    
                                  
                                        
                                        
                                   
                                     
                                       <?php
							 } 		   endforeach; ?>
                           </center>
 </tbody>
                        </table>
                        </div>
                        
                       <?php if (isset($username)) {

		 ?>
                       <strong><font color="black"><center>&gt;&gt;&gt; รายการวีพีเอ็นที่เช่า &lt;&lt;&lt;</center></font> </strong>
<div class="table-responsive" style="max-height: 200px; overflow: scroll; margin-bottom: 5px;">
    <table class="table table-hover">
					  <tbody>
<tr> <th><font color=black><center>โฮส IP</center></th>
                                    <th><font color=black><center>ชื่อผู้ใช้</center></th>
                                    <th><font color=black><center>ราคา</center></th>
                                    
                                    
                                    <th><font color=black><center>สร้างวันที่</center></th>
                                    
                                    <th><font color=black><center>วันหมดอายุ</center></th></tr>
                        
<?php foreach ($this->user_model->get_account_list($sshuser) as $row): ?>
<tr>
								
								
								<td><font color=black><center><?=$row['hostname'] ?> </center></td>
                                                <td><font color=black><center><?= $row['username'] ?></center></td>
                                                <td><font color=black><center><?= $row['price']?></center></td>
                                                
                                                
                                                <td><font color=black><center><?= $row['created_at']?></center></td>
                                                
                                                <td><font color=black><center><?= $row['expired_at']?>
</tr>

<?php endforeach;
echo '</tbody>
					</table></div>';
					?>
						<strong><font color="black"><center>&gt;&gt;&gt; ประวัติการเติมเครดิต &lt;&lt;&lt;</center></font> </strong>
<div class="table-responsive" style="max-height: 200px; overflow: scroll; margin-bottom: 5px;">
    <table class="table table-hover">
					  <tbody>
<tr><th><font color=000000><center>เลขที่อ้างอิง</center></th><th><font color=000000><center>จำนวนเงิน</center></th></tr>
                        
<?php foreach ($this->user_model->view_histrory($sshuser) as $row):  ?>
<tr>
								
								
								<td><center><?= $row['NumberWallet']?></center></td>
<td><center><?= $row['money']?></center></td>

</tr>

<?php endforeach;
echo '</tbody>
					</table></div>';
	
		  } else { 
		  echo  '<center><div class="alert alert-danger" role="alert">ชื่อ '.$sshuser.' ไม่มีในระบบ
				</div></center>';
		  }		
?>

                    </div>
                </div>
            </div>
        
		</div>
</div>
			   <?php } ?>
</div>
</div>
</div>




     