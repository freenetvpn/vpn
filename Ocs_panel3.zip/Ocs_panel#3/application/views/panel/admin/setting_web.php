<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
                   
      <h3>
       ตั้งค่าเว็บไซต์
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">ตั้งค่าเว็บไซต์</li>
    </ol>
    
        </div>
    </div>
    <div class="well"> 
    <div class="row">
        <center>
           
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   <?= form_open() ?>
				
				
				<?php foreach ($this->user_model->view_asset() as $row): ?>
					
				
     
            
    <div class="beta site-title"><img src="<?= $row['png']?>" width="100" height="100" alt="logo.ico" /> 	</div>
   
   <div class="form-group">
						<label for="png">ลิ้งโล้โก้เว็บไซต์</label>
						<input type="text" name="png" class="text-center form-control" id="png" value="<?= $row['png']?>" placeholder="www.smile-vpn.net/image.png" />
						</div>
   
				<div class="form-group">
						<label for="web">ชื่อเว็บไซต์</label>
						<input type="text" name="web" class="text-center form-control" id="web" value="<?= $row['web']?>"  placeholder="SMILE VPN" />
						</div>
					
				
					
						<div class="form-group">
						<label for="link">ลิ้งให้ลูกค้าติดต่อ</label>
						<input type="text" name="link" class="text-center form-control" id="link" value="<?= $row['link']?>"  placeholder="www.smile-vpn.net" />
						</div>
						
					<div class="form-group">
						<label for="groud">ลิ้งกลุ่มเฟส</label>
						<input type="text" name="groud" class="text-center form-control" id="groud" value="<?= $row['groud']?>"  placeholder="www.facebook.com/kariya00" />
						</div>
					
					
						
						<input type="submit" class="btn btn-primary form-control" value="อัปเดตข้อมูล"/>
					
			   </form></div></div>
			<?php endforeach; ?>
					
		   
		  