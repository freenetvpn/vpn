<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	
<div id="page-wrapper">
	<div class="row">
        <div class="col-lg-12">
                   
      <h3>
       ตั้งค่าทรูวอเล็ท
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-dashboard"></i> หน้าหลัก</a></li>
		<li class="active">ตั้งค่าระบบเติมเงิน</li>
    </ol>
    
        </div>
    </div>
    
    <div class="row">
        <center>
           
			  <?php if (isset($message)) {echo $message;} ?>
			  <?php if (validation_errors()) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= validation_errors() ?></div>
					</div>
					<?php endif; ?>
					<?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
			   <?php endif;?>
			   <?= form_open() ?>
				
				
				<?php foreach ($this->user_model->view_wallet() as $row): ?>
					
				
     
            
    
   
					<div class="bg-info box box-widget widget-user">
           <div class="widget-user-header bg-orang" style="background: url('https://www.ekstepza.com/truemoney-wallet/truemoney-wallet.png') center center; background-size: 100% 100%, auto;">

             <!--span style="font-size: 16px;"  class="badge bg-navy"> <?php if ($row['Status']) { echo '';} else {echo "เซิร์ฟเวอร์เต็ม";}?></span-->
            </div>  
            <div class="widget-user-image">
			
                 
                 
            </div>
            <div class="progress">
<div class="progress-bar" style="width: 0%"></div>
</div>
						<div class="form-group">
						<label for="link">ชื่อผู้ใช้เว็บ TH-VPN</label>
						<input type="text" name="username" style="width:80%; border:5px" class="text-center form-control" id="link" value="<?= $row['username']?>"  placeholder="username" />
						</div>
						
					<div class="form-group">
						<label for="groud">รหัสผ่านเว็บ TH-VPN</label>
						<input type="password" name="passwd" style="width:80%; border:5px" class="text-center form-control" id="groud" value="<?= $row['passwd']?>"  placeholder="passwd" />
						</div>
						
						
					<div class="form-group">
						<label for="png">เบอร์ทรูวอเล็ท</label>
						<input type="text" name="phone" style="width:80%; border:5px" class="text-center form-control" id="png" value="<?= $row['phone']?>" placeholder="09XXXXXXXX" />
						</div>
   
				<div class="form-group">
						<label for="web">รหัส PIN</label>
						<input type="text" style="width:80%; border:5px" name="pin" class="text-center form-control" id="web" value="<?= $row['pin']?>"  placeholder="รหัส PIN 4หลัก" />
						</div>
						<font size=5 color=orange>E-Wallet</font><br>
						<font color="000000">
                            <input type="checkbox" name="ewallet" value="1"/> ยืนยันแล้ว
						<input type="checkbox" name="ewallet" value="0"/> ยังไม่ยืนยัน<br>
                        </font>
						<input type="submit" style="width:80%; border:5px" class="btn btn-primary form-control" value="อัปเดตข้อมูล"/>
					
			   </form></div></div>
			<?php endforeach; ?>
					
		   
		  