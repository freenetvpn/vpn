﻿<?php
$sakariya='smilevpn';
$em='email@gmail.com';
?>
