<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
 * Copyright (c) 2006-2017 Adipati Arya <jawircodes@gmail.com>,
 * 2006-2017 http://sshcepat.com
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
class Seller extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');
		$this->load->helper('url_helper');
		$this->load->library('sshcepat');
		$this->load->library(array('session'));
	}
	private function _set_view($file, $init) {
		
		$this->load->view('panel/base/page_header');
		$this->load->view($file, $init);
        $this->load->view('panel/base/footer');
	}
	public function seller($user=FALSE) {
		
		//if (empty($user)) {show_404();}
		
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			
			$data = new stdClass();
			$data->user = $this->user_model->get_user($_SESSION['user_id']);
			$data->server=$this->user_model->get_hostname();
			$this->_set_view('panel/seller/servers', $data);
		}
		else {redirect(base_url('login/login'));}
	}
	public function addsaldo_hp() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$this->form_validation->set_rules('sender', 'Pengirim', 'trim|required|min_length[4]');
		    $this->form_validation->set_rules('hp', 'No Telp', 'trim|required|min_length[4]');
			$user = $this->user_model->get_user($_SESSION['user_id']);
			if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$data->user = $this->user_model->get_user($_SESSION['user_id']);
				$this->_set_view('panel/seller/addsaldo_hp', $data);
			} else {
				$mkios = $this->input->post('mkios');
				$sender = $this->input->post('sender');
				$hp = $this->input->post('hp');
				$jumlah= $this->input->post('jumlah');
				if (empty($mkios)) {
					$pesan = $user->username. ' ใช้หมายเลข ' .$sender. ' โอนเงินเข้าบัญชี '. $hp .' จำนวน '. $jumlah.' บาท';
					} else {
						$pesan = $user->username. ' Meminta saldo via mkios Dengan no seri ' .$mkios. ' dikirim ke nomor '.$hp.' sebesar : '. $jumlah;
					}
				$userid=$_SESSION['user_id'];
				if ($this->user_model->deposit($userid, $pesan, $jumlah)) {
					
					
					 $data = new stdClass();
					 $data -> message = 'ขอขอบคุณที่ใช้บริการเซิฟร์เวอร์ ssh ของเรา ยอดเครดิตขอคุณจะถูกเพิ่มโดยอัตโนมัติเมื่อได้รับการยืนยันจากผู้ดูแล ใช้เวลานี้ไม่เกิน 24 ชั่วโมง.';
					 $data->user = $this->user_model->get_user($_SESSION['user_id']);
					 $this->_set_view('panel/seller/addsaldo_hp', $data);
				}
				else {echo "database error";}
			}
		}
		else {redirect(base_url('login/login'));}
		
	}
	
	
	public function settin_link() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$this->form_validation->set_rules('sender', 'Pengirim', 'trim|required|min_length[10]');
		    $this->form_validation->set_rules('hp', 'No Telp', 'trim|required|min_length[10]');
			$user = $this->user_model->get_user($_SESSION['user_id']);
			if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$data->user = $this->user_model->get_user($_SESSION['user_id']);
			   $data->server=$this->user_model->get_hostname();
			 $data->wallet=$this->user_model->view_token();
			$data->wallet=$this->user_model->view_ovpn();
			$data->wallet=$this->user_model->view_web();
			$data->wallet=$this->user_model->view_user($user);
				
				$this->load->view('panel/base/page_header', $data);
				//$this->load->view('panel/base/header', $data);
				
				
			
				}
				else {echo "database error";}
			
		}
		else {redirect(base_url('login/login'));}
		
	}
	
	
	
				
			
				
	
	public function home() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$user = $this->user_model->get_user($_SESSION['user_id']);
			if ($this->form_validation->run() === false) {
				$data = new stdClass();
			   $data->msg=$this->user_model->view_msg();
				
				$this->_set_view('panel/smile', $data);
			
				}
				else {echo "database error";}
			
		}
		else {redirect(base_url('login/login'));}
		
	}
	
	public function buy($id=FALSE) {
	    $this->load->helper('form');
		$this->load->library('form_validation');
		
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
		    if ($this->user_model->get_hostname($id)->Status) {
		        if ($this->user_model->get_user($_SESSION['user_id'])->saldo < $this->user_model->get_hostname($id)->Price)
		        {
					 
					 $data = new stdClass();
					 $data->message='<p class="btn btn-danger">ยอดเครดิตไม่พอ<br> กรุณาเติมเครดิตก่อนใช้บริการ</p>';
					 $data->user = $this->user_model->get_user($_SESSION['user_id']);
					 $data->server=$this->user_model->get_hostname();
					 $this->_set_view('panel/seller/addsaldo_hp', $data);
				}
				  else {
				    $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[1]|is_unique[sshuser.username]');
				    $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[1]');
				    if ($this->form_validation->run() === false) {
				        $data = new StdClass();
				        
					    $data->user = $this->user_model->get_user($_SESSION['user_id']);
					    $data->server=$this->user_model->get_hostname($id);
					    
					    $this->load->view('panel/base/page_header');
					    $this->load->view('panel/seller/create', $data);
					    $this->load->view('panel/base/footer');
					    
				    } else {
						$server=$this->user_model->get_hostname($id);
						$by = $this->user_model->get_user($_SESSION['user_id']);
						$dat = array(
							'message' => '<div class="btn btn-success"> วีพีเอ็น พร้อมใช้งาน </div>',
						    'hostname'=>$server->HostName,
						    'rootpass'=>$server->RootPasswd,
						    'openssh'=>$server->OpenSSH,
							'dropbear'=>$server->Dropbear,
							'location'=>$server->Location,
							'price' => $server->Price,
						    'username'=>$this->input->post('username'),
						    'password'=>$this->input->post('password'),
						    'expired'=>$server->Expired
						    );
						    $ssh = $this ->sshcepat->addAccount($dat);
						    
						    
						    if($ssh) {
								 if ($this->user_model->user_ssh(
									$dat['username'],
									$dat['password'],
									$dat['hostname'],
									$by->username,
									$dat['expired'], 
									$server->Id, 
									$server->Price)) 
								{
									$saldo = $by->saldo - $server->Price;
									if ($this->user_model->update_saldo($by->username, $saldo)) {
										$data = new stdClass();
										$data->server=$this->user_model->get_hostname($id);
										$data->user = $dat;
										$this->load->view('panel/base/page_header');
										$this->load->view('panel/seller/account', $data);
										$this->load->view('panel/base/footer');
									}
								}
							} else { echo "ไม่อนุญาตให้ใช้ชื่อ root ";}
							
						}
						
				    } // end form_validation
			   } else {
				
			       
						
			        $data = new stdClass();
			        $data->user = $this->user_model->get_user($_SESSION['user_id']);
			        $data->server=$this->user_model->get_hostname();
			      $data->message='<div class="btn btn-danger"> โปรดเลือกเช่าเซิฟร์เวอร์อื่น</div>';
			        $this->_set_view('panel/seller/servers', $data); 
			       
			   } // server locked;
			
		}
		
		else {redirect(base_url('login/login'));}
		
	}
	public function smile_account($user=false) {
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$data = new StdClass();
			$data->account= $this->user_model->get_account_list($user);
			$this->_set_view('panel/seller/account_list', $data);
			
		}
		else {redirect(base_url('login/login'));}
	}
	
	
	
	
	public function delet_account($id) {
		$this->load->library('sshcepat');
		if (empty($this->user_model->id_ssh($id)->hostname)) { Show_404(); }
		$create_by = $this->user_model->id_ssh($id)->created_by;
		$data = array (
			'hostname' => $this->user_model->id_ssh($id)->hostname,
			'rootpass' => $this->user_model->get_hostname($this->user_model->id_ssh($id)->serverid)->RootPasswd,
			'username' => $this->user_model->id_ssh($id)->username
		);
		if ( isset($_SESSION['username']) && $_SESSION['logged_in'] === true ) {
			if ($_SESSION['username'] === $create_by ) {
				 if ($this->user_model->delete_user_ssh($id)) {
					if ($this->sshcepat->deletAccount($data)) {
						redirect(base_url('panel/reseller/cek_account'));
						
					} else {echo 'Root passwd wrong!';}
			} 
			} else { show_404(); } 
			
		}
		else { redirect(base_url('login/login')); }
		
	}
	
	//downloadOvpn
	public function download() {
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$data = new StdClass();
			$data->account= $this->user_model->view_ovpn();
			$this->_set_view('panel/seller/download', $data);
			
		}
		else {redirect(base_url('login/login'));}
	}
	
	//เปลียนโปรไฟล
	public function profile() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$this->form_validation->set_rules('png','png', 'trim|required|min_length[4]');
			
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$this->_set_view('panel/seller/profile', $data);
			} else {
				$post = array (
						'png' => $this->input->post('png'),
						
						 );
				if (!$this->user_model->get_profile($this->input->post('png'))) {
					if ($this->user_model->users($post)) {
						$data = new stdClass();
						$data->users=$this->user_model->view_users();
						$data->message='<div class="btn btn-success">เปลียนโปรไฟล์เรียบร้อย</div>';
						$this->_set_view('panel/seller/profile', $data);
						
					} else {echo 'Database error';} 
				}
				else {
					redirect(base_url('seller/profile'));
				}
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
	public function edit_image() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$this->form_validation->set_rules('png','png', 'trim|required|min_length[4]');
			
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$this->_set_view('panel/seller/edit_image', $data);
			} else {
				$post = array (
						'png' => $this->input->post('png'),
						
						 );
				if (!$this->user_model->get_profile($this->input->post('png'))) {
					if ($this->user_model->edit_image($post)) {
						$data = new stdClass();
						$data->edit_image=$this->user_model->view_users();
						$data->message='<div class="btn btn-success">เปลียนรูปโปรไฟล์เรียบร้อย</div>';
						$this->_set_view('panel/seller/profile', $data);
						
					} else {echo 'Database error';} 
				}
				else {
					redirect(base_url('seller/profile'));
				}
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
	public function edit_user() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$this->form_validation->set_rules('username','username', 'trim|required|min_length[4]');
			
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$this->_set_view('panel/seller/edit_user', $data);
			} else {
				$post = array (
						'username' => $this->input->post('username'),
						
						 );
				if (!$this->user_model->get_edit_user($this->input->post('username'))) {
					if ($this->user_model->edit_user($post)) {
				       
						$data = new stdClass();
						$data->edit_user=$this->user_model->view_users();
						$data->message='<div class="btn btn-success">แก้ไขชื่อใหม่เรียบร้อย <br> กรุณาออกจาระบบและล็อกอินด้วยชื่อใหม่</div><br><a class="btn btn-danger" href="/panel/'.$_SESSION['username'].'/logout">ออกจากระบบ</a>';
						$this->_set_view('panel/seller/edit_user', $data);
						
					} else {echo 'Database error';} 
				}
				else {
					$data = new stdClass();
					$data->message='<div class="btn btn-danger"> ชื่อผู้ใช้ซ้ำกับที่มีอยู่แล้ว</div>';
					$this->_set_view('panel/seller/edit_user', $data);
					
				}
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
	public function edit_sshuser() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$this->form_validation->set_rules('account_list','created_by', 'trim|required|min_length[4]');
			
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$this->_set_view('panel/seller/account_list', $data);
			} else {
				$post = array (
						'account_list' => $this->input->post('account_list'),
						
						 );
				if (!$this->user_model->edit_sshuser($this->input->post('username'))) {
					if ($this->user_model->edit_sshuser($post)) {
				       
						$data = new stdClass();
						$data->edit_sshuser=$this->user_model->view_users();
						$data->message='<div class="btn btn-success"> คืนค่าเรียบร้อย </div>';
						$this->_set_view('panel/seller/account_list', $data);
						
					} else {echo 'Database error';} 
				}
				else {
					$data = new stdClass();
					$data->message='<div class="btn btn-danger"> โปรดใส่ชื่อเก่าให้ถูกต้อง </div>';
					$this->_set_view('panel/seller/account_list', $data);
					
				}
			}
		}
		else {redirect(base_url('login/login'));}
	}
	
	
	public function edit_email() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$this->form_validation->set_rules('email', 'email', 'trim|required|valid_email[users.email]');
			
         if ($this->form_validation->run() === false) {
				$data = new stdClass();
				$this->_set_view('panel/seller/edit_email', $data);
			} else {
				$post = array (
						'email' => $this->input->post('email'),
						
						 );
				if (!$this->user_model->get_edit_email($this->input->post('email'))) {
					if ($this->user_model->edit_email($post)) {
						$data = new stdClass();
						$data->edit_email=$this->user_model->view_users();
						$data->message='<div class="btn btn-success">แก้ไขอีเมลเรียบร้อย </div> ';
						$this->_set_view('panel/seller/profile', $data);
						
					} else {echo 'Database error';} 
				}
				else {
					$data = new stdClass();
					$data->message='<div class="btn btn-danger"> อีเมลนี้ซ้ำกับที่มีอยู่ในระบบ</div>';
					$this->_set_view('panel/seller/edit_email', $data);
					
				}
			}
		}
		else {redirect(base_url('login/login'));}
	}

public function AutoWallet() {
		$this->load->helper('form');
		$this->load->library('form_validation');
		if (isset($_SESSION['username']) && $_SESSION['logged_in'] === true) {
			$this->form_validation->set_rules('wallet', 'wallet', 'trim|required|min_length[14]|is_unique[histrory.NumberWallet]', array('is_unique' => 'เลขอ้างอิงถูกใช้งานแล้ว', 'min_length' => 'ใส่ข้อมูลยืนยันให้ถูกต้อง', 'required' => 'โปรดใส่ข้อมูลการยืนยัน' ));
			require(APPPATH . 'controllers/sm-api.php');
			$walet = $this->user_model->view_wallet();
$user_sm = $walet[0]["username"];
//echo $user_sm;
$passwd = $walet[0]["passwd"];
//echo $passwd;
$phone = $walet[0]["phone"];
//echo $phone;
$pin = $walet[0]["pin"];
//echo $pin;
//echo $walet[0]["ewallet"];
if ($walet[0]["ewallet"] < 1){
$ewallet ='14000';
} else {
$ewallet ='14000'.$phone.'';
}

         if ($this->form_validation->run() === false) {
             //require(APPPATH . 'controllers/sm-api.php');
			   $data = new stdClass();
				$data->user = $this->user_model->get_user($_SESSION['user_id']);
				$data->phone = $phone;
				$data->ewallet = $ewallet;
				$this->_set_view('panel/seller/AutoWallet', $data);
			} else {
   $idwallet = $this->input->post('wallet');
   

 $api = get_api($user_sm, $passwd, $phone, $pin);
 // 
 $i=0;
 foreach ($api as $wallet) {
     if (isset($wallet->id)){
       $chekok= 'ok';
     } else if (isset($wallet->date)){
          $chekok= 'ok';
      } else {
       $filed=$api->filed;
       }
  if (isset($chekok)){
    $i++;
    if ($i <= 5){
 if ($wallet->id == $idwallet) {
$ok_wallet=$wallet->id;
} else if ($wallet->date == $idwallet) {
$ok_wallet=$wallet->id;
} else {
$filed='ข้อมูลยืนยันไม่ถูกต้อง';
}
 }
}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////

if (isset($ok_wallet)) {

if (!$this->user_model->get_otp($ok_wallet)) {
$chek = chek_api($user_sm, $passwd, $phone, $pin, $ok_wallet);

if (isset($chek->filed)){
$data = new stdClass();
                        $data->idwallet=$idwallet;
                        $data->phone = $phone;
                        $data->ewallet = $ewallet;
                        $data->filed=$chek->filed;
						$data->user = $this->user_model->get_user($_SESSION['user_id']);
						$data->no='<div class="btn btn-danger">'.$chek->filed.'</div> ';
                        $this->_set_view('panel/seller/AutoWallet', $data);
} else {
$aaa=$chek->id;
$money=$chek->mout;

if ($money >= $mout ) {
   $money = $money *((100+$bonas)/100);
  }
  
	$user=$_SESSION['username'];
   $saldo = $this->user_model->get_daysshh($_SESSION['username'])->saldo + $money;
   $mes = '';
     
	if ($this->user_model->update_saldo($user, $saldo)) {
	$this->user_model->update_history($user, $aaa, $money);
                       $data = new stdClass();
                       $data->money=$money;
                       $data->phone = $phone;
                       $data->ewallet = $ewallet;
                       $data->saldo=$saldo;
                       $data->idwallet=$aaa;
                       $data->user = $this->user_model->get_user($_SESSION['user_id']);
                       $data->yes='<div class="btn btn-success">คุณได้เติมเครดิต '.$money.' บาทสำเร็จ '.$mes.'</div> ';
                        $this->_set_view('panel/seller/AutoWallet', $data);
                        }
                        }
                        } else {
	 
   $data = new stdClass();
               $data->phone = $phone;
                $data->ewallet = $ewallet;
				$data->user = $this->user_model->get_user($_SESSION['user_id']);
				$data->no='<div class="btn btn-danger">รายการนี้ได้ยืนยันแล้ว</div>  ';
				$data->filed='รายการนี้ได้ยืนยันแล้ว ';
				$this->_set_view('panel/seller/AutoWallet', $data);
			
   }
				} else {
$data = new stdClass();
                        $data->idwallet=$idwallet;
                        $data->phone = $phone;
                        $data->ewallet = $ewallet;
						$data->user = $this->user_model->get_user($_SESSION['user_id']);
						$data->filed=$filed;
						$data->no='<div class="btn btn-danger">'.$filed.'</div> ';
                        $this->_set_view('panel/seller/AutoWallet', $data);
}

}
	} else {redirect(base_url('login/login'));
	}
	}
	

}
 