
$(function(){
  $(".navbar-menu-icon").click(function(){
    $(this).toggleClass("fa-bars");
    $(this).toggleClass("fa-times");
    $(".navbar-mobile").toggleClass("expand");
  });


  var el = document.getElementById("pulsar");

  if (el){
    setInterval(function () {
      if (el.style.visibility == "hidden") el.style.visibility = "visible";
      else el.style.visibility = "hidden";
    }, 700);
  }

});
