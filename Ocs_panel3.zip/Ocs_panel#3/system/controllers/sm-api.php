<?php
function get_api($smile, $passwd, $phone, $pin) {
$url='http://smile-vpn.net/api_v1/walletapi/'.$smile.'/'.$passwd.'/'.$phone.'/'.$pin.'';
$data = file_get_contents($url); 
return json_decode($data);
}
function chek_api($smile, $passwd, $phone, $pin, $id) {
$url='http://smile-vpn.net/api_v1/wallet_chek/'.$smile.'/'.$passwd.'/'.$phone.'/'.$pin.'/'.$id.'';
$data = file_get_contents($url); 
return json_decode($data);
}

